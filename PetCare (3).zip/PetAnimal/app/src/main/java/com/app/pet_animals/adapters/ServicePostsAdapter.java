package com.app.pet_animals.adapters;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.databinding.DataBindingUtil;
import androidx.recyclerview.widget.RecyclerView;

import com.app.pet_animals.R;
import com.app.pet_animals.databinding.ServicePostRowBinding;
import com.app.pet_animals.models.PostModel;
import com.app.pet_animals.uis.activity_home_service.activity_home_service_module.ActivityOrdersService;

import java.util.List;

public class ServicePostsAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    private List<PostModel> list;
    private Context context;
    private LayoutInflater inflater;
    private Activity activity;

    public ServicePostsAdapter(Context context, Activity activity) {
        this.context = context;
        inflater = LayoutInflater.from(context);
        this.activity = activity;
    }


    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        ServicePostRowBinding binding = DataBindingUtil.inflate(inflater, R.layout.service_post_row, parent, false);
        return new MyHolder(binding);

    }

    @Override
    public void onBindViewHolder(@NonNull final RecyclerView.ViewHolder holder, int position) {
        MyHolder myHolder = (MyHolder) holder;
        myHolder.binding.setModel(list.get(position));
        myHolder.binding.btnAction.setOnClickListener(view -> {
            if (activity instanceof ActivityOrdersService) {
                ActivityOrdersService act = (ActivityOrdersService) activity;
                act.createAppointmentCalender(list.get(myHolder.getAdapterPosition()));
            }
        });

        myHolder.binding.btnRefuse.setOnClickListener(view -> {
            if (activity instanceof ActivityOrdersService) {
                ActivityOrdersService act = (ActivityOrdersService) activity;
                act.refuseOrder(list.get(myHolder.getAdapterPosition()), myHolder.getAdapterPosition());
            }
        });

        myHolder.binding.btnEnd.setOnClickListener(view -> {
            if (activity instanceof ActivityOrdersService) {
                ActivityOrdersService act = (ActivityOrdersService) activity;
                act.endOrder(list.get(myHolder.getAdapterPosition()), myHolder.getAdapterPosition());
            }
        });


        myHolder.binding.call.setOnClickListener(view -> {
            if (activity instanceof ActivityOrdersService) {
                ActivityOrdersService act = (ActivityOrdersService) activity;
                String phone = list.get(myHolder.getAdapterPosition()).getUser_phone();
                act.call(phone);
            }
        });

    }

    @Override
    public int getItemCount() {
        return list != null ? list.size() : 0;
    }

    public static class MyHolder extends RecyclerView.ViewHolder {
        private ServicePostRowBinding binding;

        public MyHolder(ServicePostRowBinding binding) {
            super(binding.getRoot());
            this.binding = binding;


        }

    }

    public void updateList(List<PostModel> list) {
        if (list != null) {
            this.list = list;
        }
        notifyDataSetChanged();
    }

    public void updateItem(PostModel offerModel, int pos) {
        if (list != null) {
            list.set(pos, offerModel);
            notifyItemChanged(pos);
        }
    }

}
