package com.app.pet_animals.uis.activity_home_service.activity_profile_service_module;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.databinding.DataBindingUtil;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.widget.Toast;

import com.app.pet_animals.R;
import com.app.pet_animals.databinding.ActivityProfileServiceBinding;
import com.app.pet_animals.language.Language;
import com.app.pet_animals.models.UserModel;
import com.app.pet_animals.tags.Common;
import com.app.pet_animals.tags.Tags;
import com.app.pet_animals.uis.activity_base.ActivityBase;
import com.app.pet_animals.uis.activity_home_service.HomeActivityService;
import com.app.pet_animals.uis.activity_login.LoginActivity;
import com.app.pet_animals.uis.activity_sign_up.SignUpActivity;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import io.paperdb.Paper;

public class ActivityProfileService extends ActivityBase {
    private ActivityProfileServiceBinding binding;
    private DatabaseReference dRef;
    private ActivityResultLauncher<Intent> launcher;
    private int req;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = DataBindingUtil.setContentView(this, R.layout.activity_profile_service);

        launcher = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), result -> {
            if (req == 1 && result.getResultCode() == Activity.RESULT_OK) {
                binding.setModel(getUserModel());
            }
        });

        initView();
    }

    private void initView() {
        binding.setLang(getLang());
        binding.setModel(getUserModel());
        binding.cardLogout.setOnClickListener(view -> {
            logout();
        });

        binding.switchBtn.setOnClickListener(view -> {
            boolean checked = binding.switchBtn.isChecked();
            updateServiceStatus(checked);
        });

        binding.llUpdateProfile.setOnClickListener(view -> {
            req = 1;
            Intent intent = new Intent(this, SignUpActivity.class);
            launcher.launch(intent);
        });
        binding.tvLanguage.setOnClickListener(view -> {
            String lang = getLang();
            if (lang.equals("ar")){
                lang = "en";
            }else {
                lang = "ar";
            }

            refreshActivity(lang);
        });


        getRate();

    }

    private void updateServiceStatus(boolean checked) {
        dRef = FirebaseDatabase.getInstance().getReference();
        ProgressDialog dialog = Common.createProgressDialog(this, getString(R.string.wait));
        dialog.setCancelable(false);
        dialog.show();

        dRef.child(Tags.table_users)
                .child(getUserModel().getUser_id())
                .child("canReceiveOrders")
                .setValue(checked)
                .addOnSuccessListener(unused -> {
                    dialog.dismiss();
                    UserModel model = getUserModel();
                    model.setCanReceiveOrders(checked);
                    setUserModel(model);
                    binding.setModel(model);

                }).addOnFailureListener(e -> {
                    dialog.dismiss();
                    UserModel model = getUserModel();
                    binding.setModel(model);
                    Toast.makeText(ActivityProfileService.this, e.getMessage(), Toast.LENGTH_SHORT).show();


                });
    }

    private void getRate() {
        dRef = FirebaseDatabase.getInstance().getReference();

        dRef.child(Tags.table_users)
                .child(getUserModel().getUser_id())
                .child("rate")
                .addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        if (snapshot.getValue() != null) {
                            long rate = (long) snapshot.getValue();
                            binding.setRate(rate+"");

                        } else {
                            binding.setRate("0");
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });
    }

    public void logout() {
        FirebaseAuth mAuth = FirebaseAuth.getInstance();
        if (mAuth.getCurrentUser() != null) {
            mAuth.signOut();
            clearUserModel();
            navigateToLoginActivity();
        }
    }

    private void navigateToLoginActivity() {
        Intent intent = new Intent(this, LoginActivity.class);
        startActivity(intent);
        finish();
    }

    public void refreshActivity(String lang) {
        Paper.book().write("lang", lang);
        Language.setNewLocale(this, lang);
        new Handler()
                .postDelayed(() -> {

                    Intent intent = getIntent();
                    finish();
                    startActivity(intent);
                }, 500);
    }
}