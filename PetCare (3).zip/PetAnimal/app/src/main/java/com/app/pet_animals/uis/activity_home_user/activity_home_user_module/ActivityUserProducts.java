package com.app.pet_animals.uis.activity_home_user.activity_home_user_module;

import androidx.databinding.DataBindingUtil;
import androidx.recyclerview.widget.LinearLayoutManager;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.app.pet_animals.R;
import com.app.pet_animals.adapters.UserProductsAdapter;
import com.app.pet_animals.databinding.ActivityUserProductsBinding;
import com.app.pet_animals.models.Product;
import com.app.pet_animals.uis.activity_base.ActivityBase;

import java.util.ArrayList;
import java.util.List;

public class ActivityUserProducts extends ActivityBase {
    private ActivityUserProductsBinding binding;
    private UserProductsAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = DataBindingUtil.setContentView(this, R.layout.activity_user_products);

        initView();
    }

    private void initView() {
        binding.recViewLayout.tvNoData.setText(R.string.no_orders);
        binding.recViewLayout.tvNoData.setVisibility(View.GONE);
        adapter = new UserProductsAdapter(this, this.getLang(), this);
        binding.recViewLayout.recView.setLayoutManager(new LinearLayoutManager(this));
        binding.recViewLayout.recView.setAdapter(adapter);
        binding.recViewLayout.swipeRefresh.setOnRefreshListener(this::getProducts);
        getProducts();
    }

    private void getProducts() {
        binding.recViewLayout.swipeRefresh.setRefreshing(false);
        List<Product> list = new ArrayList<>();

        Product p1 = new Product(
                getResources().getString(R.string.product_title_1),
                getResources().getString(R.string.product_desc_1),
                R.drawable.product_a,
                130);
        list.add(p1);
        ///////////////
        Product p2 = new Product(
                getResources().getString(R.string.product_title_2),
                getResources().getString(R.string.product_desc_2),
                R.drawable.product_b,
                60);
        list.add(p2);
        ///////////////
        Product p3 = new Product(
                getResources().getString(R.string.product_title_3),
                getResources().getString(R.string.product_desc_3),
                R.drawable.product_c,
                120);
        list.add(p3);
        ///////////////
        Product p4 = new Product(
                getResources().getString(R.string.product_title_4),
                getResources().getString(R.string.product_desc_4),
                R.drawable.product_d,
                150);
        list.add(p4);
        ///////////////
        Product p5 = new Product(
                getResources().getString(R.string.product_title_5),
                getResources().getString(R.string.product_desc_5),
                R.drawable.product_e,
                50);
        list.add(p5);
        ///////////////
        Product p6 = new Product(
                getResources().getString(R.string.product_title_6),
                getResources().getString(R.string.product_desc_6),
                R.drawable.product_f,
                49);
        list.add(p6);
        ///////////////
        Product p7 = new Product(
                getResources().getString(R.string.product_title_7),
                getResources().getString(R.string.product_desc_7),
                R.drawable.product_g,
                110);
        list.add(p7);
        ///////////////


        adapter.updateList(list);
    }

    public void navigateToProductDetails(Product productModel){
        Intent intent = new Intent(this, ActivityUserProductDetails.class);
        intent.putExtra("data", productModel);
        startActivity(intent);
    }
}