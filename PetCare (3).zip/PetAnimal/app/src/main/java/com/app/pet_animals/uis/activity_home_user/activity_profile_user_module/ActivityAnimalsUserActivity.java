package com.app.pet_animals.uis.activity_home_user.activity_profile_user_module;

import androidx.annotation.NonNull;
import androidx.databinding.DataBindingUtil;
import androidx.recyclerview.widget.LinearLayoutManager;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import com.app.pet_animals.R;
import com.app.pet_animals.adapters.AnimalAdapter;
import com.app.pet_animals.databinding.ActivityAnimalsUserBinding;
import com.app.pet_animals.models.AnimalModel;
import com.app.pet_animals.tags.Common;
import com.app.pet_animals.tags.Tags;
import com.app.pet_animals.uis.activity_base.ActivityBase;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.util.ArrayList;
import java.util.List;

public class ActivityAnimalsUserActivity extends ActivityBase {
    ActivityAnimalsUserBinding binding;
    private AnimalAdapter adapter;
    private DatabaseReference dRef;
    private StorageReference sRef;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = DataBindingUtil.setContentView(this, R.layout.activity_animals_user);
        initView();
    }

    private void initView() {
        adapter = new AnimalAdapter(this, this);
        binding.recViewLayout.recView.setLayoutManager(new LinearLayoutManager(this));
        binding.recViewLayout.recView.setAdapter(adapter);
        binding.recViewLayout.tvNoData.setText(R.string.no_pet_animal);
        binding.recViewLayout.tvNoData.setVisibility(View.GONE);
        binding.recViewLayout.swipeRefresh.setOnRefreshListener(this::getAnimals);
        binding.fab.setOnClickListener(view -> {
            Intent intent = new Intent(this, ActivityUserAddAnimal.class);
            startActivity(intent);
        });
        getAnimals();
    }

    private void getAnimals() {
        binding.recViewLayout.swipeRefresh.setRefreshing(true);
        dRef = FirebaseDatabase.getInstance().getReference();
        Query query = dRef.child(Tags.table_animal);
        query.orderByChild("owner_id")
                .equalTo(getUserModel().getUser_id())
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        binding.recViewLayout.swipeRefresh.setRefreshing(false);
                        if (snapshot.getValue() != null) {
                            List<AnimalModel> animalModelList = new ArrayList<>();
                            for (DataSnapshot ds : snapshot.getChildren()) {
                                AnimalModel animalModel = ds.getValue(AnimalModel.class);
                                if (animalModel != null) {
                                    animalModelList.add(animalModel);
                                }
                            }

                            if (animalModelList.size() > 0) {
                                binding.recViewLayout.tvNoData.setVisibility(View.GONE);

                            } else {
                                binding.recViewLayout.tvNoData.setVisibility(View.VISIBLE);

                            }
                            adapter.updateList(animalModelList);

                        } else {
                            binding.recViewLayout.tvNoData.setVisibility(View.VISIBLE);
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });
    }

    public void delete(AnimalModel animalModel, int adapterPosition) {
        ProgressDialog dialog = Common.createProgressDialog(this, getString(R.string.wait));
        dialog.setCanceledOnTouchOutside(false);
        dialog.setCancelable(false);
        dialog.show();
        sRef = FirebaseStorage.getInstance().getReference();
        StorageReference mSRef = sRef.child(Tags.animals_image).child(animalModel.getAnimal_id());
        mSRef.delete().addOnSuccessListener(unused -> {
            removeAnimalData(animalModel,adapterPosition,dialog);
        }).addOnFailureListener(e -> {
            dialog.dismiss();
            Toast.makeText(this, e.getMessage(), Toast.LENGTH_SHORT).show();

        });

    }

    private void removeAnimalData(AnimalModel animalModel, int adapterPosition, ProgressDialog dialog) {
        dRef = FirebaseDatabase.getInstance().getReference();
        dRef.child(Tags.table_animal).child(animalModel.getAnimal_id())
                .removeValue()
                .addOnSuccessListener(unused -> {
                    dialog.dismiss();
                    adapter.removeItem(adapterPosition);
                    if (adapter.getList()!=null&&adapter.getList().size()==0){
                        binding.recViewLayout.tvNoData.setVisibility(View.VISIBLE);
                    }else {
                        binding.recViewLayout.tvNoData.setVisibility(View.GONE);

                    }
                }).addOnFailureListener(e -> {
                    dialog.dismiss();
                    Toast.makeText(ActivityAnimalsUserActivity.this, e.getMessage(), Toast.LENGTH_SHORT).show();

                });
    }

    public void update(AnimalModel animalModel, int adapterPosition) {
        Intent intent = new Intent(this, ActivityUserAddAnimal.class);
        intent.putExtra("data", animalModel);
        startActivity(intent);
    }
}