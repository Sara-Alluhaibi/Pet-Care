package com.app.pet_animals.adapters;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.databinding.DataBindingUtil;
import androidx.recyclerview.widget.RecyclerView;

import com.app.pet_animals.R;
import com.app.pet_animals.databinding.ProductItemBinding;
import com.app.pet_animals.models.Product;
import com.app.pet_animals.uis.activity_home_user.activity_home_user_module.ActivityUserProducts;

import java.util.List;

public class UserProductsAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    private List<Product> list;
    private Context context;
    private LayoutInflater inflater;
    private String lang;
    private Activity activity;

    public UserProductsAdapter(Context context, String lang, Activity activity) {
        this.context = context;
        inflater = LayoutInflater.from(context);
        this.lang = lang;
        this.activity = activity;
    }


    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        ProductItemBinding binding = DataBindingUtil.inflate(inflater, R.layout.product_item, parent, false);
        return new MyHolder(binding);

    }

    @Override
    public void onBindViewHolder(@NonNull final RecyclerView.ViewHolder holder, int position) {
        MyHolder myHolder = (MyHolder) holder;
        myHolder.binding.setModel(list.get(position));
        myHolder.binding.setLang(lang);

        myHolder.itemView.setOnClickListener(view -> {
            if (activity instanceof ActivityUserProducts){
                ActivityUserProducts act = (ActivityUserProducts) activity;
                act.navigateToProductDetails(list.get(myHolder.getAdapterPosition()));
            }
        });

    }

    @Override
    public int getItemCount() {
        return list!=null?list.size():0;
    }

    public static class MyHolder extends RecyclerView.ViewHolder {
        private ProductItemBinding binding;

        public MyHolder(ProductItemBinding binding) {
            super(binding.getRoot());
            this.binding = binding;


        }

    }

    public void updateList(List<Product> list){
        if (list!=null){
            this.list = list;
        }
        notifyDataSetChanged();
    }

}
