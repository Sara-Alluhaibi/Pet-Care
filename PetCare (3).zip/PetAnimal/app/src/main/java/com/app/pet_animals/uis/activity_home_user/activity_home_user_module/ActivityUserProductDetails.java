package com.app.pet_animals.uis.activity_home_user.activity_home_user_module;

import androidx.appcompat.app.AppCompatActivity;
import androidx.databinding.DataBindingUtil;

import android.os.Bundle;

import com.app.pet_animals.R;
import com.app.pet_animals.databinding.ActivityUserProductDetailsBinding;
import com.app.pet_animals.databinding.ActivityUserProductsBinding;
import com.app.pet_animals.models.Product;

public class ActivityUserProductDetails extends AppCompatActivity {
    private ActivityUserProductDetailsBinding binding;
    private Product product;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = DataBindingUtil.setContentView(this, R.layout.activity_user_product_details);
        product = (Product) getIntent().getSerializableExtra("data");

        initView();
    }

    private void initView() {
        binding.setModel(product);
    }
}