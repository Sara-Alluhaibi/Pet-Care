package com.app.pet_animals.uis.activity_home_user.activity_profile_user_module;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.databinding.DataBindingUtil;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;

import com.app.pet_animals.R;
import com.app.pet_animals.databinding.ActivityProfileUserBinding;
import com.app.pet_animals.language.Language;
import com.app.pet_animals.models.PostModel;
import com.app.pet_animals.tags.Tags;
import com.app.pet_animals.uis.activity_base.ActivityBase;
import com.app.pet_animals.uis.activity_login.LoginActivity;
import com.app.pet_animals.uis.activity_sign_up.SignUpActivity;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import io.paperdb.Paper;

public class ActivityProfileUser extends ActivityBase {
    private ActivityProfileUserBinding binding;
    private DatabaseReference dRef;
    private ActivityResultLauncher<Intent> launcher;
    private int req;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = DataBindingUtil.setContentView(this, R.layout.activity_profile_user);

        launcher = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), result -> {
            if (req == 1 && result.getResultCode() == Activity.RESULT_OK) {
                binding.setModel(getUserModel());
            }
        });
        initView();
    }

    private void initView() {
        binding.setLang(getLang());
        binding.setModel(getUserModel());
        binding.setOrderCount("0");
        binding.cardLogout.setOnClickListener(view -> {
            this.logout();
        });

        binding.llAnimals.setOnClickListener(view -> {
            Intent intent = new Intent(this, ActivityAnimalsUserActivity.class);
            startActivity(intent);
        });

        binding.llPosts.setOnClickListener(view -> {
            Intent intent = new Intent(this, ActivityOrdersUser.class);
            startActivity(intent);
        });

        binding.llFavorite.setOnClickListener(view -> {
            Intent intent = new Intent(this, ActivityFavoriteUser.class);
            startActivity(intent);
        });

        binding.llEditProfile.setOnClickListener(view -> {
            req = 1;
            Intent intent = new Intent(this, SignUpActivity.class);
            launcher.launch(intent);
        });

        binding.tvLanguage.setOnClickListener(view -> {
            String lang = getLang();
            if (lang.equals("ar")){
                lang = "en";
            }else {
                lang = "ar";
            }
            this.refreshActivity(lang);
        });

        getPostsCount();


    }

    private void getPostsCount() {
        dRef = FirebaseDatabase.getInstance().getReference();
        Query query = dRef.child(Tags.table_posts)
                .orderByChild("user_id")
                .equalTo(getUserModel().getUser_id());
        query.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.getValue() != null) {
                    int count = 0;
                    for (DataSnapshot ds : snapshot.getChildren()) {
                        PostModel postModel = ds.getValue(PostModel.class);
                        if (postModel != null && postModel.getPost_status().equals(Tags.status_accepted)) {
                            count++;
                        }
                    }

                    binding.setOrderCount(count + "");

                } else {
                    binding.setOrderCount("0");
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }

    public void logout() {
        FirebaseAuth mAuth = FirebaseAuth.getInstance();
        if (mAuth.getCurrentUser() != null) {
            mAuth.signOut();
            clearUserModel();
            navigateToLoginActivity();
        }
    }

    private void navigateToLoginActivity() {
        Intent intent = new Intent(this, LoginActivity.class);
        startActivity(intent);
        finish();
    }

    public void refreshActivity(String lang) {
        Paper.book().write("lang", lang);
        Language.setNewLocale(this, lang);
        new Handler()
                .postDelayed(() -> {

                    Intent intent = getIntent();
                    finish();
                    startActivity(intent);
                }, 500);


    }
}