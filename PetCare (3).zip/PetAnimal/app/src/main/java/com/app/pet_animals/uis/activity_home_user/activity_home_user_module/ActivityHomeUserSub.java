package com.app.pet_animals.uis.activity_home_user.activity_home_user_module;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.databinding.DataBindingUtil;
import androidx.navigation.Navigation;
import androidx.recyclerview.widget.LinearLayoutManager;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Toast;

import com.app.pet_animals.R;
import com.app.pet_animals.adapters.ServiceAdapter;
import com.app.pet_animals.databinding.ActivityHomeUserSubBinding;
import com.app.pet_animals.databinding.FilterDialogBinding;
import com.app.pet_animals.models.UserModel;
import com.app.pet_animals.tags.Tags;
import com.app.pet_animals.uis.activity_add_post.ActivityAddPost;
import com.app.pet_animals.uis.activity_base.ActivityBase;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class ActivityHomeUserSub extends ActivityBase {
    private ActivityHomeUserSubBinding binding;
    private ServiceAdapter adapter;
    private DatabaseReference dRef;
    private String filterBy = Tags.user_housing_owner;
    private String dialogFilterQuery = filterBy;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = DataBindingUtil.setContentView(this, R.layout.activity_home_user_sub);
        initView();
    }

    private void initView() {
        binding.recViewLayout.tvNoData.setText(R.string.no_data);
        dRef = FirebaseDatabase.getInstance().getReference();
        binding.recViewLayout.recView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new ServiceAdapter(this,getLang(),this);
        binding.recViewLayout.recView.setAdapter(adapter);
        binding.recViewLayout.swipeRefresh.setColorSchemeResources(R.color.colorPrimary);
        binding.recViewLayout.swipeRefresh.setOnRefreshListener(this::filter);
        binding.recViewLayout.tvNoData.setText(R.string.no_data);
        binding.recViewLayout.tvNoData.setVisibility(View.GONE);

        binding.imageFilter.setOnClickListener(view -> showFilterDialog());
        binding.cardSearch.setOnClickListener(view -> {
            Intent intent = new Intent(this, ActivityUserSearch.class);
            startActivity(intent);
        });
        //getAllServiceProviders();
        filter();
    }

    private void getAllServiceProviders() {
        binding.recViewLayout.swipeRefresh.setRefreshing(true);
        binding.recViewLayout.tvNoData.setVisibility(View.GONE);
        Query query = dRef.child(Tags.table_users);
        query.orderByChild("filter_attr")
                .equalTo(Tags.filter_service)
                .limitToFirst(20)
                .addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        binding.recViewLayout.swipeRefresh.setRefreshing(false);
                        List<UserModel> serviceList = new ArrayList<>();
                        if (snapshot.getValue()!=null){
                            for (DataSnapshot ds :snapshot.getChildren()){
                                UserModel userModel = ds.getValue(UserModel.class);
                                if (userModel!=null){
                                    serviceList.add(userModel);
                                }
                            }

                            if (serviceList.size()>0){
                                adapter.updateList(sortedList(serviceList));
                                binding.recViewLayout.tvNoData.setVisibility(View.GONE);
                            }else {
                                binding.recViewLayout.tvNoData.setVisibility(View.VISIBLE);

                            }
                        }else {
                            binding.recViewLayout.tvNoData.setVisibility(View.VISIBLE);

                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                        Toast.makeText(ActivityHomeUserSub.this, error.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });
    }

    private void filter() {
        binding.recViewLayout.swipeRefresh.setRefreshing(true);
        binding.recViewLayout.tvNoData.setVisibility(View.GONE);
        Query query = dRef.child(Tags.table_users);
        query.orderByChild("user_type")
                .equalTo(filterBy)
                .limitToFirst(20)
                .addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        binding.recViewLayout.swipeRefresh.setRefreshing(false);
                        List<UserModel> guidesList = new ArrayList<>();
                        if (snapshot.getValue()!=null){
                            for (DataSnapshot ds :snapshot.getChildren()){
                                UserModel userModel = ds.getValue(UserModel.class);
                                if (userModel!=null){
                                    guidesList.add(userModel);
                                }
                            }

                            if (guidesList.size()>0){
                                adapter.updateList(sortedList(guidesList));
                                binding.recViewLayout.tvNoData.setVisibility(View.GONE);
                            }else {
                                binding.recViewLayout.tvNoData.setVisibility(View.VISIBLE);

                            }
                        }else {
                            binding.recViewLayout.tvNoData.setVisibility(View.VISIBLE);

                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                        Toast.makeText(ActivityHomeUserSub.this, error.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });
    }

    private List<UserModel> sortedList(List<UserModel> list) {
        Collections.sort(list, (m1, m2) -> Double.compare(m2.getRate(),m1.getRate()));
        return list;
    }

    private void showFilterDialog(){
        BottomSheetDialog dialog = new BottomSheetDialog(this);
        dialog.setCancelable(true);
        dialog.setCanceledOnTouchOutside(true);
        FilterDialogBinding filterDialogBinding = DataBindingUtil.inflate(LayoutInflater.from(this),R.layout.filter_dialog,null,false);
        if (filterBy.equals(Tags.user_housing_owner)){
            filterDialogBinding.rbHouse.setChecked(true);
        }else if (filterBy.equals(Tags.user_doctor)){
            filterDialogBinding.rbDoctor.setChecked(true);

        }else {
            filterDialogBinding.rbAll.setChecked(true);

        }

        filterDialogBinding.rbAll.setOnCheckedChangeListener((compoundButton, b) -> {
            if (b){
                dialogFilterQuery ="all";
            }
        });
        filterDialogBinding.rbDoctor.setOnCheckedChangeListener((compoundButton, b) -> {
            if (b){
                dialogFilterQuery = Tags.user_doctor;
            }
        });

        filterDialogBinding.rbHouse.setOnCheckedChangeListener((compoundButton, b) -> {
            if (b){
                dialogFilterQuery = Tags.user_housing_owner;
            }
        });

        filterDialogBinding.btnFilter.setOnClickListener(view -> {
            filterBy = dialogFilterQuery;

            if (dialogFilterQuery.equals("all")){
                getAllServiceProviders();
            }else {
                filter();
            }

            dialog.dismiss();
        });

        filterDialogBinding.imageClose.setOnClickListener(view -> dialog.dismiss());

        dialog.setContentView(filterDialogBinding.getRoot());
        dialog.show();
    }

    public void navigateToSendPosActivity(UserModel model) {
        Intent intent = new Intent(this, ActivityAddPost.class);
        intent.putExtra("id",model.getUser_id());
        intent.putExtra("name",model.getFirst_name()+" "+model.getLast_name());
        intent.putExtra("phone",model.getPhone_code()+model.getPhone());
        startActivity(intent);
    }

}