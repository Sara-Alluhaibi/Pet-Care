package com.app.pet_animals.uis.activity_home_service;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;

import androidx.databinding.DataBindingUtil;

import com.app.pet_animals.R;
import com.app.pet_animals.databinding.ActivityHomeServiceBinding;
import com.app.pet_animals.language.Language;
import com.app.pet_animals.uis.activity_base.ActivityBase;
import com.app.pet_animals.uis.activity_home_service.activity_home_service_module.ActivityOrdersService;
import com.app.pet_animals.uis.activity_home_service.activity_profile_service_module.ActivityProfileService;
import com.app.pet_animals.uis.activity_login.LoginActivity;
import com.google.firebase.auth.FirebaseAuth;

import io.paperdb.Paper;

public class HomeActivityService extends ActivityBase {
    private ActivityHomeServiceBinding binding;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = DataBindingUtil.setContentView(this, R.layout.activity_home_service);
        initView();
    }

    private void initView() {
        binding.cardOrders.setOnClickListener(view -> {
            Intent intent = new Intent(this, ActivityOrdersService.class);
            startActivity(intent);
        });

        binding.cardProfile.setOnClickListener(view -> {
            Intent intent = new Intent(this, ActivityProfileService.class);
            startActivity(intent);
        });
    }

    public void logout() {
        FirebaseAuth mAuth = FirebaseAuth.getInstance();
        if (mAuth.getCurrentUser() != null) {
            mAuth.signOut();
            clearUserModel();
            navigateToLoginActivity();
        }
    }

    private void navigateToLoginActivity() {
        Intent intent = new Intent(this, LoginActivity.class);
        startActivity(intent);
        finish();
    }

    public void refreshActivity(String lang) {
        Paper.book().write("lang", lang);
        Language.setNewLocale(this, lang);
        new Handler()
                .postDelayed(() -> {

                    Intent intent = getIntent();
                    finish();
                    startActivity(intent);
                }, 500);
    }

}