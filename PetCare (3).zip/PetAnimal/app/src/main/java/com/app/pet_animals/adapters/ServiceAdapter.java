package com.app.pet_animals.adapters;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.databinding.DataBindingUtil;
import androidx.recyclerview.widget.RecyclerView;

import com.app.pet_animals.R;
import com.app.pet_animals.databinding.ServiceRowBinding;
import com.app.pet_animals.models.UserModel;
import com.app.pet_animals.uis.activity_home_user.activity_home_user_module.ActivityDoctorsUser;
import com.app.pet_animals.uis.activity_home_user.activity_home_user_module.ActivityHomeUserSub;
import com.app.pet_animals.uis.activity_home_user.activity_home_user_module.ActivityUserSearch;

import java.util.List;

public class ServiceAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    private List<UserModel> list;
    private Context context;
    private LayoutInflater inflater;
    private String lang;
    private Activity activity;

    public ServiceAdapter(Context context, String lang,Activity activity) {
        this.context = context;
        inflater = LayoutInflater.from(context);
        this.lang = lang;
        this.activity = activity;
    }


    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        ServiceRowBinding binding = DataBindingUtil.inflate(inflater, R.layout.service_row, parent, false);
        return new MyHolder(binding);

    }

    @Override
    public void onBindViewHolder(@NonNull final RecyclerView.ViewHolder holder, int position) {
        MyHolder myHolder = (MyHolder) holder;
        myHolder.binding.setModel(list.get(position));
        myHolder.binding.setLang(lang);

        myHolder.itemView.setOnClickListener(view -> {
            if (activity instanceof ActivityHomeUserSub){
                ActivityHomeUserSub act = (ActivityHomeUserSub) activity;
                act.navigateToSendPosActivity(list.get(myHolder.getAdapterPosition()));
            }else  if (activity instanceof ActivityDoctorsUser){
                ActivityDoctorsUser act = (ActivityDoctorsUser) activity;
                act.navigateToSendPosActivity(list.get(myHolder.getAdapterPosition()));
            }else if (activity instanceof ActivityUserSearch){
                ActivityUserSearch act = (ActivityUserSearch) activity;
                act.navigateToSendPosActivity(list.get(myHolder.getAdapterPosition()));
            }
        });

    }

    @Override
    public int getItemCount() {
        return list!=null?list.size():0;
    }

    public static class MyHolder extends RecyclerView.ViewHolder {
        private ServiceRowBinding binding;

        public MyHolder(ServiceRowBinding binding) {
            super(binding.getRoot());
            this.binding = binding;


        }

    }

    public void updateList(List<UserModel> list){
        if (list!=null){
            this.list = list;
        }
        notifyDataSetChanged();
    }

}
